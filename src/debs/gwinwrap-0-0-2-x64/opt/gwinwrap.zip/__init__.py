"""
    Start of package.
"""
