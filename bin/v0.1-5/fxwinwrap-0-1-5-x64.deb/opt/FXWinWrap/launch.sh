#!/bin/bash

function main() {
    java -Xms32m -Xmx100m -jar FXWinWrap.jar
}
main;
