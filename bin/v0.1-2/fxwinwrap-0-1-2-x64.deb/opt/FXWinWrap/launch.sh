#!/bin/bash

java XWWMenu
